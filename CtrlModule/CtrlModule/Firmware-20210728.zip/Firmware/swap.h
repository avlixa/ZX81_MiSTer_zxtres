#ifndef SWAP_H
#define SWAP_H

unsigned int SwapBBBB(unsigned int i);
unsigned int SwapBB(unsigned int i);
unsigned int SwapWW(unsigned int i);

#endif

